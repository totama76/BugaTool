"""
Gestión de base de datos SQLite
Conexiones y configuración de base de datos
"""