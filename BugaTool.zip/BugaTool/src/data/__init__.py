"""
Capa de Acceso a Datos
Gestiona la persistencia de datos con SQLite
"""