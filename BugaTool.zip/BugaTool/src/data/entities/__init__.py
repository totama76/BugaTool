"""
Entidades de datos
Representan las estructuras de datos en la base de datos
"""