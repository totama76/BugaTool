"""
Repositorios de datos
Implementan el patrón Repository para acceso a datos
"""