"""
Sistema de Control de Presión para Raspberry Pi
Arquitectura de 3 capas: Presentación, Negocio, Datos
"""

__version__ = "0.1.0"
__author__ = "Sistema para totama76"
__description__ = "Sistema de Control Electrónico de Presión"