"""
Capa de Lógica de Negocio
Gestiona las reglas de negocio y servicios del sistema
"""