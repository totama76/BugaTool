"""
Servicios de lógica de negocio
Implementan las reglas de negocio del sistema
"""