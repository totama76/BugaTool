"""
Controladores para la interfaz PyQt6/QML
Intermediarios entre la UI y la lógica de negocio
"""