"""
Capa de Presentación - PyQt6 + QML
Responsable de la interfaz de usuario y visualización
"""