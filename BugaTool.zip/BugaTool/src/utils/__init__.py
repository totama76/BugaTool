"""
Utilidades del sistema
Funciones y clases auxiliares transversales
"""